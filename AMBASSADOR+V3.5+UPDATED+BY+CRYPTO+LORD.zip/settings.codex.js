/*

  © Created by :
  
  C O D E X 𝐋𝐎𝐑𝐃 (Developer)

  
  WARNING..!!
- Don't recode this script 
- Don't sell or buy this script 

© Copyright 2021 - 2025 

*/
const fs = require('fs')

global.botname = "𝐀𝐌𝐁𝐀𝐒𝐒𝐀𝐃𝐎𝐑"
global.version = "𝟑.𝟓"
global.owner = "2348111713979"
global.footer = "C o d e x 𝐥𝐨𝐫𝐝"
global.idch = "120363322464215140@newsletter"

//Global Thumb
global.thumb = "https://i.ibb.co/YT82z7W7/0a89c22bce6d5de2.jpg"

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
